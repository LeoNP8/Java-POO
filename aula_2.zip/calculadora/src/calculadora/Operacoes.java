package calculadora;

public class Operacoes {
    float a, b, resultado;

    public Operacoes(float a, float b, float resultado) {
        this.a = a;
        this.b = b;
        this.resultado = resultado;
    }
    
    public Operacoes() {
        
    }
    
    public void soma(float a, float b){
        resultado = a + b;
        System.out.println(resultado);
    }
    
    public void subtracao(float a, float b){
        resultado = a - b;
        System.out.println(resultado);
    }
    
    public void multiplicacao(float a, float b){
        resultado = a * b;
        System.out.println(resultado);
    }
    
    public void divisao(float a, float b){
        resultado = a / b;
        System.out.printf("%.2f", resultado);
    }
}

