package calculadora;
import java.util.Locale;
import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Locale.setDefault(Locale.US);
        
        System.out.println("primeiro numero");
        float numero1 = sc.nextFloat();
        
        System.out.println("segundo numero");
        float numero2 = sc.nextFloat();
        
        
        Operacoes calc = new Operacoes(); 
        calc.soma(numero1, numero2);
        calc.subtracao(numero1, numero2);
        calc.multiplicacao(numero1, numero2);
        calc.divisao(numero1, numero2);
        
        
        
        
        
        
        
        sc.close();
    }
    
}
